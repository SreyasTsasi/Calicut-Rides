const Database = require("better-sqlite3");
const path = require("path");

const db = new Database(process.env.DB_FILE || path.join(__dirname, "calicut-rides.db"));
db.pragma("journal_mode = WAL");
db.pragma("foreign_keys = ON");

db.exec(`
CREATE TABLE IF NOT EXISTS bikes (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  type TEXT NOT NULL,
  cc INTEGER NOT NULL DEFAULT 110,
  area TEXT NOT NULL,
  address TEXT NOT NULL DEFAULT '',
  price_hour INTEGER NOT NULL,
  price_day INTEGER NOT NULL,
  deposit INTEGER NOT NULL DEFAULT 1000,
  description TEXT NOT NULL DEFAULT '',
  available INTEGER NOT NULL DEFAULT 1
);
CREATE TABLE IF NOT EXISTS bookings (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  bike_id INTEGER NOT NULL REFERENCES bikes(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  phone TEXT NOT NULL,
  licence_no TEXT NOT NULL,
  start_ts INTEGER NOT NULL,
  hours INTEGER NOT NULL,
  total INTEGER NOT NULL,
  status TEXT NOT NULL DEFAULT 'active',
  created_at INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_bookings_bike ON bookings(bike_id, status);
CREATE INDEX IF NOT EXISTS idx_bookings_phone ON bookings(phone);
`);

if (db.prepare("SELECT COUNT(*) c FROM bikes").get().c === 0) {
  const ins = db.prepare(`INSERT INTO bikes
    (name,type,cc,area,address,price_hour,price_day,deposit,description)
    VALUES (?,?,?,?,?,?,?,?,?)`);
  [
    ["Honda Activa 6G", "Scooter", 110, "Beach Road", "Near Kozhikode Beach, Beach Road", 60, 450, 1000, "Easy automatic for city rides and beach evenings."],
    ["TVS Jupiter", "Scooter", 110, "Mananchira", "Near Mananchira Square, SM Street", 55, 420, 1000, "Light, with under-seat storage for a bag."],
    ["Suzuki Access 125", "Scooter", 125, "Feroke", "Feroke Junction", 65, 500, 1000, "Smooth 125cc scooter for longer trips."],
    ["Hero Splendor", "Commuter", 100, "Palayam", "Palayam Bus Stand", 50, 400, 1000, "Reliable and fuel efficient."],
    ["Bajaj Pulsar 150", "Commuter", 150, "Mavoor Road", "Mavoor Road, near the bus stand", 80, 650, 2000, "Sporty 150cc for highway stretches."],
    ["Royal Enfield Hunter 350", "Cruiser", 350, "Kallai", "Kallai Road", 120, 1000, 3000, "Compact 350 for Wayanad and ghat roads."],
    ["Royal Enfield Classic 350", "Cruiser", 350, "Beach Road", "Near Kozhikode Beach, Beach Road", 140, 1200, 3000, "The classic long-ride bike."],
    ["Yamaha R15 V4", "Sports", 155, "Medical College", "Medical College Junction", 160, 1400, 4000, "Fully faired sports bike. Experienced riders only."]
  ].forEach(r => ins.run(...r));
}

module.exports = db;
