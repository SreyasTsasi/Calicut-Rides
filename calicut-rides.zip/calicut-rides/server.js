require("dotenv").config();
const express = require("express");
const path = require("path");
const crypto = require("crypto");
const db = require("./db");

const app = express();
const PORT = process.env.PORT || 3000;
const ADMIN_TOKEN = process.env.ADMIN_TOKEN || "";
const TYPES = ["Scooter", "Commuter", "Cruiser", "Sports"];
const HOUR = 3600 * 1000;

app.use(express.json({ limit: "20kb" }));
app.use(express.static(path.join(__dirname, "public")));

/* ---------- helpers ---------- */
const bad = (res, msg, code = 400) => res.status(code).json({ error: msg });
const clean = (s, n = 80) => String(s ?? "").trim().slice(0, n);

function price(bike, hours) {
  if (hours >= 24) return Math.ceil(hours / 24) * bike.price_day;
  return Math.min(hours * bike.price_hour, bike.price_day);
}

function isFree(bikeId, startTs, hours, ignoreId = 0) {
  const endTs = startTs + hours * HOUR;
  const row = db.prepare(`SELECT 1 FROM bookings
    WHERE bike_id=? AND status='active' AND id<>?
    AND start_ts < ? AND (start_ts + hours*3600000) > ? LIMIT 1`).get(bikeId, ignoreId, endTs, startTs);
  return !row;
}

function adminOnly(req, res, next) {
  const given = Buffer.from(String(req.get("x-admin-token") || ""));
  const real = Buffer.from(ADMIN_TOKEN);
  if (!ADMIN_TOKEN || given.length !== real.length || !crypto.timingSafeEqual(given, real))
    return bad(res, "Owner access denied.", 401);
  next();
}

/* ---------- public API ---------- */
app.get("/api/bikes", (req, res) => {
  const { area, type } = req.query;
  let sql = "SELECT * FROM bikes WHERE 1=1";
  const args = [];
  if (area) { sql += " AND area=?"; args.push(area); }
  if (type) { sql += " AND type=?"; args.push(type); }
  res.json(db.prepare(sql + " ORDER BY price_hour").all(...args));
});

app.get("/api/areas", (_req, res) => {
  res.json(db.prepare("SELECT DISTINCT area FROM bikes ORDER BY area").all().map(r => r.area));
});

app.get("/api/bikes/:id/busy", (req, res) => {
  const rows = db.prepare(`SELECT start_ts, hours FROM bookings
    WHERE bike_id=? AND status='active' AND start_ts + hours*3600000 > ?`).all(req.params.id, Date.now());
  res.json(rows);
});

app.post("/api/bookings", (req, res) => {
  const b = req.body || {};
  const bike = db.prepare("SELECT * FROM bikes WHERE id=?").get(+b.bike_id);
  if (!bike) return bad(res, "Bike not found.", 404);
  if (!bike.available) return bad(res, "This bike is not available right now.", 409);

  const name = clean(b.name, 60);
  const phone = clean(b.phone, 15).replace(/[\s-]/g, "");
  const licence = clean(b.licence_no, 20).toUpperCase();
  const startTs = Number(b.start_ts);
  const hours = Math.floor(Number(b.hours));

  if (name.length < 2) return bad(res, "Enter your name.");
  if (!/^(\+91)?[6-9][0-9]{9}$/.test(phone)) return bad(res, "Enter a valid 10-digit Indian mobile number.");
  if (licence.length < 8) return bad(res, "Enter your driving licence number.");
  if (!Number.isFinite(startTs) || startTs < Date.now()) return bad(res, "Choose a pickup time that is still ahead.");
  if (!(hours >= 1 && hours <= 168)) return bad(res, "Rental must be between 1 hour and 7 days.");

  const insert = db.transaction(() => {
    if (!isFree(bike.id, startTs, hours)) return null;
    return db.prepare(`INSERT INTO bookings (bike_id,name,phone,licence_no,start_ts,hours,total,created_at)
      VALUES (?,?,?,?,?,?,?,?)`).run(bike.id, name, phone, licence, startTs, hours, price(bike, hours), Date.now());
  });
  const r = insert();
  if (!r) return bad(res, "This bike is already booked for that time. Try another time or bike.", 409);
  res.status(201).json(db.prepare("SELECT * FROM bookings WHERE id=?").get(r.lastInsertRowid));
});

app.get("/api/bookings", (req, res) => {
  const phone = clean(req.query.phone, 15).replace(/[\s-]/g, "");
  if (!phone) return bad(res, "Enter the phone number you booked with.");
  res.json(db.prepare(`SELECT bk.*, b.name AS bike_name, b.area, b.address, b.deposit
    FROM bookings bk JOIN bikes b ON b.id=bk.bike_id
    WHERE bk.phone=? ORDER BY bk.start_ts DESC`).all(phone));
});

app.post("/api/bookings/:id/cancel", (req, res) => {
  const phone = clean(req.body?.phone, 15).replace(/[\s-]/g, "");
  const bk = db.prepare("SELECT * FROM bookings WHERE id=?").get(req.params.id);
  if (!bk || bk.phone !== phone) return bad(res, "Booking not found for this phone number.", 404);
  if (bk.start_ts - Date.now() < HOUR) return bad(res, "Bookings can be cancelled up to 1 hour before pickup. Call the owner.", 409);
  db.prepare("UPDATE bookings SET status='cancelled' WHERE id=?").run(bk.id);
  res.json({ ok: true });
});

/* ---------- owner API ---------- */
app.get("/api/admin/check", adminOnly, (_req, res) => res.json({ ok: true }));

app.get("/api/admin/bookings", adminOnly, (_req, res) => {
  res.json(db.prepare(`SELECT bk.*, b.name AS bike_name FROM bookings bk
    JOIN bikes b ON b.id=bk.bike_id ORDER BY bk.start_ts DESC LIMIT 200`).all());
});

app.post("/api/admin/bikes", adminOnly, (req, res) => {
  const b = req.body || {};
  const name = clean(b.name, 60);
  if (!name || !TYPES.includes(b.type) || !clean(b.area)) return bad(res, "Name, type and area are required.");
  const ph = Math.floor(+b.price_hour), pd = Math.floor(+b.price_day) || ph * 8;
  if (!(ph >= 20)) return bad(res, "Hourly price must be at least ₹20.");
  const r = db.prepare(`INSERT INTO bikes (name,type,cc,area,address,price_hour,price_day,deposit,description)
    VALUES (?,?,?,?,?,?,?,?,?)`).run(name, b.type, Math.floor(+b.cc) || 110, clean(b.area), clean(b.address, 120),
    ph, pd, Math.floor(+b.deposit) || 1000, clean(b.description, 200));
  res.status(201).json({ id: r.lastInsertRowid });
});

app.patch("/api/admin/bikes/:id", adminOnly, (req, res) => {
  db.prepare("UPDATE bikes SET available=? WHERE id=?").run(req.body?.available ? 1 : 0, req.params.id);
  res.json({ ok: true });
});

app.delete("/api/admin/bikes/:id", adminOnly, (req, res) => {
  db.prepare("DELETE FROM bikes WHERE id=?").run(req.params.id);
  res.json({ ok: true });
});

app.post("/api/admin/bookings/:id/status", adminOnly, (req, res) => {
  const s = req.body?.status;
  if (!["active", "completed", "cancelled"].includes(s)) return bad(res, "Invalid status.");
  db.prepare("UPDATE bookings SET status=? WHERE id=?").run(s, req.params.id);
  res.json({ ok: true });
});

app.use("/api", (_req, res) => bad(res, "Not found.", 404));
app.listen(PORT, () => console.log(`Calicut Rides running on http://localhost:${PORT}`));
